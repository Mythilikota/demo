  <footer>
    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-5">
            <h3 class=""></h3>
          </div>
          <div class="col-md-5 col-sm-7">
            <form id="newsletter-validate-detail" method="post" action="#">
             
            </form>
          </div>
          <div class="col-md-4 col-sm-12">
            <div class="social">
              <ul class="inline-mode">
                <li class="social-network fb"><a title="Connect us on Facebook" target="_blank" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                <li class="social-network googleplus"><a title="Connect us on Google+" target="_blank" href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>
                <li class="social-network tw"><a title="Connect us on Twitter" target="_blank" href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                <li class="social-network linkedin"><a title="Connect us on Linkedin" target="_blank" href="https://www.pinterest.com/"><i class="fa fa-linkedin"></i></a></li>
                <li class="social-network rss"><a title="Connect us on Instagram" target="_blank" href="#"><i class="fa fa-rss"></i></a></li>
                <li class="social-network instagram"><a title="Connect us on Instagram" target="_blank" href="https://instagram.com/"><i class="fa fa-instagram"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-md-4 col-xs-12 col-lg-3">
          <div class="footer-logo"><a href="/shop/version3/indexk.php"><img src="/shop/version3/images/footer-logo.png" alt="fotter logo"></a> </div>
          <div class="footer-content">
            <div class="email"> <i class="fa fa-envelope"></i>
              <p>Support@themes.com</p>
            </div>
            <div class="phone"> <i class="fa fa-phone"></i>
              <p>(800) 0123 456 789</p>
            </div>
            <div class="address"> <i class="fa fa-map-marker"></i>
              <p> My Company, 12/34 - West 21st Street, New York, USA</p>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-xs-12 col-lg-3 collapsed-block">
          <div class="footer-links">
            <h3 class="links-title">Information<a class="expander visible-xs" href="#TabBlock-1">+</a></h3>
            <div class="tabBlock" id="TabBlock-1">
              <ul class="list-links list-unstyled">
			   <li><a href="/shop/version3/indexk.php">Home</a></li>
			   <li><a href="/shop/version3/laptops.php">Laptops</a></li>
                <li><a href="/shop/version3/electronics.php">Electronics</a></li>
                <li><a href="/shop/version3/kitchenware.php">Appliances</a></li>
                <li><a href="/shop/version3/homeDecorations.php">Home & Furniture</a></li>
                
                
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-xs-12 col-lg-3 collapsed-block">
          <div class="footer-links">
            <h3 class="links-title">Insider<a class="expander visible-xs" href="#TabBlock-3">+</a></h3>
            <div class="tabBlock" id="TabBlock-3">
              <ul class="list-links list-unstyled">
				<li><a href="/shop/version3/men.php">Men</a></li>
                <li> <a href="/shop/version3/women.php">Women </a> </li>
                <li> <a href="/shop/version3/baby.php">Baby& Kids </a> </li>
                <li> <a href="contact_us.html">Contact Us</a> </li>
                <li> <a href="/shop/version3/useritems.php">My Orders</a> </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-2 col-xs-12 col-lg-3 collapsed-block">
          <div class="footer-links">
            <h3 class="links-title">Service<a class="expander visible-xs" href="#TabBlock-4">+</a></h3>
            <div class="tabBlock" id="TabBlock-4">
              <ul class="list-links list-unstyled">
                <li> <a href="/shop/version3/login.php">Account</a> </li>
                <li> <a href="/shop/version3/useritems.php">Wishlist</a> </li>
                <li> <a href="/shop/version3/viewcart.php">Shopping Cart</a> </li>
                <li> <a href="#">Return Policy</a> </li>
               
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-coppyright">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-xs-12 coppyright"> Copyright © 2017 <a href="#"> Fancy </a>. All Rights Reserved. </div>
          <div class="col-sm-6 col-xs-12">
            <div class="payment">
              <ul>
                <li><a href="#"><img title="Visa" alt="Visa" src="/shop/version3/images/visa.png"></a></li>
                <li><a href="#"><img title="Paypal" alt="Paypal" src="/shop/version3/images/paypal.png"></a></li>
                <li><a href="#"><img title="Discover" alt="Discover" src="/shop/version3/images/discover.png"></a></li>
                <li><a href="#"><img title="Master Card" alt="Master Card" src="/shop/version3/images/master-card.png"></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a href="#" id="back-to-top" title="Back to top"><i class="fa fa-angle-up"></i></a> 